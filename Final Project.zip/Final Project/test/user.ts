var should = require('should');
describe('my test series', function() {
  it('should do smth', function(done){...})
  it('should do smth else', function(done){...})
})
