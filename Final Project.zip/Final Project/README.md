# Welcome to my ReadMe
## Introduction
This readme will teach you everything you need to know about this program

## Installation
You simply have to open your node.js prompt and launch : **node index.js**


Then type on your url : **localhost:1337/**

## Usage
To make this program work you shoud add **hello/your name here** to the url and see what happens !


Enter the name of the developper to get a suprise (His name is Arthur)

**For example:**

_hello/Max_ should give you "Hello Max"

_hello/Arthur_ should give you "Hello my name is Arthur, I live in Paris and I can see the eiffel tower from my window"

## Developpers
This program has been developped by _Arthur Varin_